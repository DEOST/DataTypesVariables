﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8.@string
{
    class Program
    {
        static void Main()
        {
            string variable = "The use of quotations causes difficulties.
";

    Console.WriteLine(variable);
        }
    }
}
